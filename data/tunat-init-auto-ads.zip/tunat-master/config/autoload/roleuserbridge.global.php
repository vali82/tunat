<?php
return array(
    'roleuserbridge' => array(
        /**
         * Table name for your linking table
         */
        'user_role_linker' => 'user_role_linker',
		/**
         * Default role for new user
         */
        'user_role_id'     => 'parcauto'
	)
);
